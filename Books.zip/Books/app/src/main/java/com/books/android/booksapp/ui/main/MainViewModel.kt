package com.books.android.booksapp.ui.main

class MainViewModel {
}