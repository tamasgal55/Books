package com.books.android.booksapp.ui.details

class Details {
}